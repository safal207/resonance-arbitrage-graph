# PR #85 — bounded live wallet-watch proof

**PASS for this one-provider, one-transfer scope.** A live read of one existing finalized Ethereum USDC transfer passed transaction lookup, an independent fresh-database one-block scan, durable history, and ordinary process restart/replay. This is not a live arrival/latency experiment or a whole-PR release approval.

## Exact identity and observation

- Repository: https://github.com/safal207/resonance-arbitrage-graph
- PR: https://github.com/safal207/resonance-arbitrage-graph/pull/85
- Source head: `e2d644155b587da89b12116a9b94150c6e5d4837`. Detached, tracked-clean local checkout; remote head matched before and after collection.
- Collection: 2026-09-06T17:03:47.531346+00:00 through 2026-09-06T17:08:04.201460+00:00.
- Provider: `ethereum-rpc.publicnode.com` only; default public HTTPS RPC; no API credentials.
- Chain: Ethereum mainnet, observed chain ID `0x1`.
- USDC contract: `0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48`. Matches Circle's [mainnet address documentation](https://developers.circle.com/stablecoins/usdc-contract-addresses), checked 2026-09-06. This reference identifies the token; it does not independently verify the selected event.
- Address observed: `0xa677353b8b6053039c51db9dcc1a420e76d33c84`. Public sample selected by a deterministic rule, no ownership or entity attribution.
- Transaction: `0xbe18af1609eba93e7e25d18e46c5d6662e15ee92ac6f029864e5feede515cf35`; log index `5`.
- Explorer convenience link: https://etherscan.io/tx/0xbe18af1609eba93e7e25d18e46c5d6662e15ee92ac6f029864e5feede515cf35. Explorer was not used as a second event-verification source.
- Block: `25919603`; hash `0xff41bbf3c7e150735e6e6e4d8e4f294fb94d08983fcd2fdcba1a9ffbf950d565`.
- Amount: `300000000` integer token units = **300.000000 USDC**. No fetched USD valuation.
- Event identity: `1:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48:0xbe18af1609eba93e7e25d18e46c5d6662e15ee92ac6f029864e5feede515cf35:5`.
- Acquisition label: `LIVE_RPC`. Verification label: `RPC_CONSISTENT_FINALIZED`.

## Observed outcomes

| Check | Result |
| --- | --- |
| Fresh transaction lookup | 1 event, 1 console notification |
| History in a new process | 1 event; saved digest and event projection verify |
| Transaction replay after restart | 0 new events, 0 notifications; history unchanged |
| Fresh scan of block 25919603 only | 1 event, 1 notification; same event identity and facts |
| Replay in the reopened scan database | 0 new events, 0 notifications; history unchanged |
| Scan checkpoint after restart/replay | Same block number and hash |
| Drain pending notifications | 0 output records |
| Commands | 9 CLI processes, all exit code 0 |

The two fresh databases deliberately each emitted once: **2 outputs across 2 isolated databases, 1 distinct event identity**. There were zero additional notifications when replaying against the same database. Do not describe this as one global delivery or an exactly-once guarantee.

Discovery read USDC Transfer logs for one finalized block. It chose the first log-index transfer of at least 1 USDC whose nonzero recipient appeared in exactly one returned transfer for that block. This is a bounded convenience sample, not random sampling or a completeness benchmark. Both address filters were exercised by the actual one-block scan.

The original PR source files were not edited. `run_live_proof.py` adds only an observation wrapper around `urllib` response reads, retaining returned bytes without altering requests or results. Each actual CLI command runs in a fresh subprocess. The RPC requests and exact JSON response bytes, including receipt and block responses, are retained by phase. Requests are recorded as parsed JSON. Only four read-only methods were used. No provider fallback occurred.

## Recheck the saved evidence offline

With Python 3.11+ and a checkout of the pinned source revision:

```bash
python verify_bundle.py --repo /absolute/path/to/resonance-arbitrage-graph --bundle /absolute/path/to/wallet-live-proof-85
```

This checks the closed manifest, source-file hashes, raw response digests and request IDs, SQLite evidence using the original verifier, equality of both paths' event projections, actual scan log identity, and restart output counts. It performs no network requests and does not create new live evidence. It uses SQLite read-only connections.

## Repeat this exact specimen live

From a checkout of the pinned revision, choose new database paths for a fresh attempt. These commands use the same public endpoint explicitly and a 1 USDC notification threshold:

```bash
PYTHONPATH=src python -m resonance_arbitrage_graph.wallet_watch_cli transaction \
  --rpc-url https://ethereum-rpc.publicnode.com \
  --address 0xa677353b8b6053039c51db9dcc1a420e76d33c84 \
  --tx 0xbe18af1609eba93e7e25d18e46c5d6662e15ee92ac6f029864e5feede515cf35 --min-usdc 1 --db wallet-data/proof85-new-transaction.sqlite3

PYTHONPATH=src python -m resonance_arbitrage_graph.wallet_watch_cli history \
  --db wallet-data/proof85-new-transaction.sqlite3

# Repeat the transaction command with the SAME database: expected 0 new / 0 output.

PYTHONPATH=src python -m resonance_arbitrage_graph.wallet_watch_cli scan \
  --rpc-url https://ethereum-rpc.publicnode.com \
  --address 0xa677353b8b6053039c51db9dcc1a420e76d33c84 \
  --start-block 25919603 --batch-size 1 --min-usdc 1 \
  --db wallet-data/proof85-new-scan.sqlite3

# Repeat transaction lookup against the scan database to test replay after restart.
# Do not repeat --start-block against an existing checkpoint.
```

`run_live_proof.py --repo /absolute/repo --out /new/empty/attempt-directory` repeats the bounded protocol with a newly selected finalized-block specimen; it does not pin this historical transaction. It stops if that one discovery block has no qualifying sample or a check fails. Preserve failed attempts and use a new directory to retry. Provider availability and historical access may change.

## Claim boundary

Supported statement:

> On source head `e2d644155b587da89b12116a9b94150c6e5d4837`, a bounded live read of one existing Ethereum USDC transfer through one public RPC provider produced an RPC-consistent finalized event, local console output and durable SQLite history. Transaction lookup and a one-block scan agreed. Ordinary process restart and replay added no duplicate event or notification in either database.

Still outside this proof:

- Independent provider agreement, consensus or cryptographic receipt-inclusion verification, provider source authenticity, and independently established log completeness.
- Continuous `watch` operation, unattended reliability, detection of an arrival after monitoring started, notification latency, or full wallet history.
- Advancing a resumed scan into another block. The persisted checkpoint was verified unchanged; replay used transaction lookup so the experiment stayed within the selected block.
- Email, Telegram, mobile push, human receipt, hosted service availability, crash-window exactly-once delivery. The implementation's at-least-once output/acknowledgment crash boundary remains.
- Signing, sending a transfer, orders, trading signals, arbitrage execution, profit, wallet ownership, entity intent or USD valuation.
- A new full regression-suite run, review approval, merge or deployment. This task made no repository change or PR-description update.

Synthetic CI evidence remains synthetic and separate. This live packet supplements it; it does not relabel it.

Evidence completion: **COMPLETE for the declared live slice**. Evidence grade: **F2**, one bounded real-world specimen with two collection paths through the same provider; no independent-verification grade is claimed.

## Files and integrity

`result.json` holds measured counts; `commands.json` holds process boundaries and exit codes; `remote-identity.json` and `provenance.json` bind the revision; `*-rpc/` holds requests and exact response bytes; `*.stdout.jsonl` and `*.stderr.txt` hold command output; the two SQLite files preserve durable state. Helpers are included for reproduction and offline validation.

`manifest.json` lists every file in the bundle except itself. SHA-256 checks detect byte changes relative to this manifest; they do not prove provider truth, an externally signed timestamp or integrity against someone rewriting both artifacts and manifest.
