#!/usr/bin/env python3
"""Offline bundle byte checks and original PR event-evidence verification."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--bundle', type=Path, required=True)
args = parser.parse_args()
root = args.bundle.resolve()
manifest = json.loads((root / 'manifest.json').read_text())
assert manifest['manifest_excludes'] == ['manifest.json']
expected = set()
for item in manifest['artifacts']:
    relative = item['path']
    path = (root / relative).resolve()
    assert path.is_relative_to(root) and not (root / relative).is_symlink()
    assert relative not in expected
    expected.add(relative)
    raw = path.read_bytes()
    assert len(raw) == item['size_bytes']
    assert hashlib.sha256(raw).hexdigest() == item['sha256'], relative
actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} - {'manifest.json'}
assert actual == expected
provenance = json.loads((root / 'provenance.json').read_text())
head = subprocess.check_output(['git', '-C', str(args.repo), 'rev-parse', 'HEAD'], text=True).strip()
assert head == provenance['expected_head_sha']
for relative, digest in provenance['source_files'].items():
    assert hashlib.sha256((args.repo / relative).read_bytes()).hexdigest() == digest
sys.path.insert(0, str(args.repo / 'src'))
from resonance_arbitrage_graph.wallet_watch import History, decode_log, verify_evidence

events = []
for name in ('transaction.sqlite3', 'scan.sqlite3'):
    with sqlite3.connect(f'file:{root / name}?mode=ro', uri=True) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute('SELECT * FROM events').fetchall()
        assert len(rows) == 1
        packet = History._checked(rows[0])
        assert packet['origin'] == 'LIVE_RPC'
        event = verify_evidence(packet['evidence'], packet['event']['watched_address'])
        assert event == packet['event']
        assert conn.execute('SELECT COUNT(*) FROM outbox WHERE emitted_at IS NOT NULL').fetchone()[0] == 1
        assert conn.execute('SELECT COUNT(*) FROM outbox WHERE emitted_at IS NULL').fetchone()[0] == 0
        events.append(event)
assert events[0] == events[1]
requests = 0
scan_logs = []
for request_file in sorted(root.glob('*-rpc/*.request.json')):
    request = json.loads(request_file.read_text())
    assert request['source_hostname'] == 'ethereum-rpc.publicnode.com'
    assert request['status'] == 'RESPONSE_CAPTURED' and request['http_status'] == 200
    response_bytes = (request_file.parent / request['response_file']).read_bytes()
    assert hashlib.sha256(response_bytes).hexdigest() == request['response_sha256']
    response = json.loads(response_bytes)
    assert response['jsonrpc'] == '2.0' and response['id'] == request['request']['id']
    assert 'result' in response and 'error' not in response
    method = request['request']['method']
    assert method in ('eth_chainId', 'eth_getBlockByNumber', 'eth_getLogs', 'eth_getTransactionReceipt')
    if method == 'eth_chainId':
        assert response['result'] == '0x1'
    if request_file.parent.name == '05-one-block-scan-rpc' and method == 'eth_getLogs':
        query = request['request']['params'][0]
        assert query['fromBlock'] == query['toBlock'] == hex(events[0]['block_number'])
        scan_logs.extend(decode_log(log) for log in response['result'])
    requests += 1
assert len(scan_logs) == 1
assert scan_logs[0]['tx_hash'] == events[0]['tx_hash'] and scan_logs[0]['log_index'] == events[0]['log_index']
commands = json.loads((root / 'commands.json').read_text())
assert len(commands) == 9 and all(command['exit_code'] == 0 for command in commands)
for phase in ('03-transaction-restart', '07-scan-db-restart-replay'):
    lines = (root / f'{phase}.stdout.jsonl').read_text().splitlines()
    assert len(lines) == 1
    record = json.loads(lines[0])
    assert record['new_events'] == record['console_notifications'] == 0
result = json.loads((root / 'result.json').read_text())
assert result['status'] == 'PASS' and result['event'] == events[0]
assert result['checkpoint_before_restart'] == result['checkpoint_after_restart']
assert (root / '09-pending-notifications.stdout.jsonl').read_bytes() == b''
print(json.dumps({'status': 'PASS', 'files_verified': len(expected), 'rpc_responses_verified': requests,
                  'events_per_database': 1, 'offline_event_projection': 'PASS',
                  'scope': 'offline integrity and consistency; no new live observation or independent source verification'}))
