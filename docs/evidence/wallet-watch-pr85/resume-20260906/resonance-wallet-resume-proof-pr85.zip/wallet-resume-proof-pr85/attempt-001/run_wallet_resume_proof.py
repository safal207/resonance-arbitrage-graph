#!/usr/bin/env python3
"""Advance the original PR85 live scan checkpoint by exactly one block."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys

HEAD = "e2d644155b587da89b12116a9b94150c6e5d4837"
ARCHIVE_SHA = "6c6122bd85437f598629b3dfeb1f7599013b2586dac7d969963f090fc6903e7f"
DB_SHA = "8e43bfff660fb11fa132865c9da2264761699e7ed7c79c8f6a4dd8db24e1e2a7"
ADDRESS = "0xa677353b8b6053039c51db9dcc1a420e76d33c84"
TX = "0xbe18af1609eba93e7e25d18e46c5d6662e15ee92ac6f029864e5feede515cf35"
BLOCK = 25919603


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def snapshot(db):
    with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as connection:
        connection.row_factory = sqlite3.Row
        state = dict(connection.execute("SELECT * FROM state WHERE id=1").fetchone())
        events = [dict(row) for row in connection.execute("SELECT * FROM events ORDER BY event_id")]
        outbox = [dict(row) for row in connection.execute("SELECT * FROM outbox ORDER BY event_id")]
    return {"state": state, "events": events, "outbox": outbox}


def check(value, message):
    if not value:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    repo, baseline, out = args.repo.resolve(), args.baseline.resolve(), args.out.resolve()
    git = lambda *a: subprocess.check_output(["git", "-C", str(repo), *a], text=True).strip()
    check(git("rev-parse", "HEAD") == HEAD, "Source head mismatch")
    check(not git("status", "--porcelain", "--untracked-files=no"), "Tracked source is dirty")
    check(sha(baseline / "scan.sqlite3") == DB_SHA, "Baseline DB hash mismatch")
    out.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(baseline / "scan.sqlite3", out / "scan.before.sqlite3")
    shutil.copyfile(baseline / "scan.sqlite3", out / "scan.sqlite3")
    shutil.copyfile(baseline / "run_live_proof.py", out / "capture_cli.py")
    shutil.copyfile(Path(__file__).resolve(), out / "run_wallet_resume_proof.py")
    working = out / "scan.sqlite3"
    before = snapshot(working)
    config = json.loads(before["state"]["config"])
    check(config["address"] == ADDRESS and config["origin"] == "LIVE_RPC" and
          config["minimum_units"] == "1000000", "Unexpected original watch configuration")
    check(before["state"]["cursor_number"] == BLOCK and len(before["events"]) == 1,
          "Unexpected original checkpoint/history")
    old_id = before["events"][0]["event_id"]
    save(out / "state.before.json", before)
    provenance = {"source_head_sha": HEAD, "source_hostname": "ethereum-rpc.publicnode.com",
                  "origin": "LIVE_RPC", "started_at": now(), "python": sys.version,
                  "baseline_archive_sha256": ARCHIVE_SHA, "baseline_database_sha256": DB_SHA,
                  "baseline_evidence_commit": "dc445bfac231ba6a3bcaac9c6388805d163c3c75",
                  "capture": "original PR85 urllib read wrapper, unchanged response bytes",
                  "source_files": {p: sha(repo / p) for p in (
                      "src/resonance_arbitrage_graph/wallet_watch.py",
                      "src/resonance_arbitrage_graph/wallet_watch_cli.py")}}
    save(out / "provenance.json", provenance)
    result = {"status": "INCOMPLETE", "source_head_sha": HEAD,
              "scope": "one-block advancement after ordinary process restart, one provider"}
    commands = []

    def run(phase, argv):
        start = now()
        command = [sys.executable, str(out / "capture_cli.py"), "--repo", str(repo),
                   "--out", str(out), "--child", "--phase", phase, "--", *argv]
        print(json.dumps({"phase": phase, "status": "STARTED", "at": start}), flush=True)
        try:
            completed = subprocess.run(command, capture_output=True, timeout=180)
            stdout, stderr, code = completed.stdout, completed.stderr, completed.returncode
        except subprocess.TimeoutExpired as exc:
            stdout, stderr, code = exc.stdout or b"", exc.stderr or b"", 124
        (out / f"{phase}.stdout.jsonl").write_bytes(stdout)
        (out / f"{phase}.stderr.txt").write_bytes(stderr)
        commands.append({"phase": phase, "argv": argv, "started_at": start,
                         "finished_at": now(), "exit_code": code, "fresh_process": True})
        save(out / "commands.json", commands)
        check(code == 0, f"{phase} failed with exit code {code}; retained stderr")
        values = [json.loads(line) for line in stdout.splitlines() if line]
        print(json.dumps({"phase": phase, "status": "DONE", "output_records": len(values)}), flush=True)
        return values

    common = ["--address", ADDRESS, "--min-usdc", "1", "--db", str(working)]
    try:
        initial_history = run("01-history-before", ["history", "--db", str(working)])
        check(len(initial_history) == 1 and initial_history[0]["event"]["event_id"] == old_id,
              "Original history did not reproduce")
        scan = run("02-resume-one-block", ["scan", *common, "--batch-size", "1"])
        summary = scan[-1]
        check(summary["status"] == "scanned" and summary["from_block"] == BLOCK + 1 and
              summary["through_block"] == BLOCK + 1, "Scan did not advance exactly one block")
        notifications = [item for item in scan if item.get("type") == "transfer_notification"]
        check(all(item["event_id"] != old_id for item in notifications), "Previous event emitted again")
        after_scan = snapshot(working)
        save(out / "state.after-scan.json", after_scan)
        check(after_scan["state"]["cursor_number"] == BLOCK + 1, "Checkpoint did not advance")
        check(after_scan["state"]["config"] == before["state"]["config"], "Watch configuration changed")
        check([row for row in after_scan["events"] if row["event_id"] == old_id] == before["events"],
              "Original event evidence changed")
        check([row for row in after_scan["outbox"] if row["event_id"] == old_id] == before["outbox"],
              "Original notification acknowledgment changed")
        check(len(after_scan["events"]) == 1 + summary["new_events"], "Event count mismatch")
        check(len(notifications) == summary["console_notifications"], "Notification count mismatch")
        history_after = run("03-history-after-scan", ["history", "--db", str(working)])
        replay = run("04-restart-old-transaction", ["transaction", *common, "--tx", TX])
        check(len(replay) == 1 and replay[0]["new_events"] == 0 and
              replay[0]["console_notifications"] == 0, "Ordinary replay duplicated an event or output")
        final_history = run("05-history-after-replay", ["history", "--db", str(working)])
        check(final_history == history_after, "History changed after replay")
        drained = run("06-drain-pending", ["notifications", "--db", str(working)])
        check(drained == [], "Unexpected pending output")
        final_state = snapshot(working)
        save(out / "state.final.json", final_state)
        check(final_state == after_scan, "State changed after replay/drain")
        check(sha(baseline / "scan.sqlite3") == DB_SHA, "Original baseline was modified")
        result.update(status="PASS", watched_address=ADDRESS, original_event_id=old_id,
                      checkpoint_before=[BLOCK, before["state"]["cursor_hash"]],
                      checkpoint_after=[BLOCK + 1, after_scan["state"]["cursor_hash"]],
                      resumed_scan=summary, original_event_notifications_on_scan=0,
                      restart_replay=replay[0], pending_notifications=0,
                      original_event_and_outbox_unchanged=True, original_baseline_unchanged=True,
                      final_history_events=len(final_history), fresh_cli_processes=len(commands))
    except Exception as exc:
        result.update(status="INCOMPLETE", error_type=type(exc).__name__, error=str(exc))
        save(out / "state.at-stop.json", snapshot(working))
    finally:
        provenance["finished_at"] = now()
        provenance["final_source_head_sha"] = git("rev-parse", "HEAD")
        provenance["tracked_source_dirty"] = bool(git("status", "--porcelain", "--untracked-files=no"))
        if provenance["final_source_head_sha"] != HEAD or provenance["tracked_source_dirty"]:
            result["status"] = "HOLD"
        save(out / "provenance.json", provenance)
        save(out / "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
