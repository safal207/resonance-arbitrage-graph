#!/usr/bin/env python3
"""Offline integrity/state verification; never converts an incomplete scan to PASS."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

HEAD = "e2d644155b587da89b12116a9b94150c6e5d4837"
DB_SHA = "8e43bfff660fb11fa132865c9da2264761699e7ed7c79c8f6a4dd8db24e1e2a7"
BLOCK = 25919603
PROVIDER = "ethereum-rpc.publicnode.com"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def snapshot(path):
    with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as conn:
        conn.row_factory = sqlite3.Row
        require(conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok", "SQLite integrity")
        return {
            "state": dict(conn.execute("SELECT * FROM state WHERE id=1").fetchone()),
            "events": [dict(r) for r in conn.execute("SELECT * FROM events ORDER BY event_id")],
            "outbox": [dict(r) for r in conn.execute("SELECT * FROM outbox ORDER BY event_id")],
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--bundle", required=True, type=Path)
    args = parser.parse_args()
    root, repo = args.bundle.resolve(), args.repo.resolve()
    git = lambda *a: subprocess.check_output(["git", "-C", str(repo), *a], text=True).strip()
    require(git("rev-parse", "HEAD") == HEAD, "Wrong source head")
    require(not git("status", "--porcelain", "--untracked-files=no"), "Tracked source changed")
    manifest = read(root / "manifest.json")
    files = {p.relative_to(root).as_posix(): p for p in root.rglob("*")
             if p.is_file() and p != root / "manifest.json"}
    require(set(files) == set(manifest["files"]), "Payload inventory mismatch")
    for name, path in files.items():
        require(sha(path) == manifest["files"][name], f"Digest mismatch: {name}")
    sys.path.insert(0, str(repo / "src"))
    from resonance_arbitrage_graph import wallet_watch as ww

    totals = {"responses": 0, "failed_requests": 0}
    failed_requests = []
    for attempt in ("attempt-001", "attempt-002"):
        directory = root / attempt
        provenance = read(directory / "provenance.json")
        require(provenance["source_head_sha"] == provenance["final_source_head_sha"] == HEAD,
                "Attempt source head mismatch")
        require(provenance["tracked_source_dirty"] is False, "Dirty attempt source")
        for name, digest in provenance["source_files"].items():
            require(sha(repo / name) == digest, "Source file digest mismatch")
        require(provenance["source_hostname"] == PROVIDER and provenance["origin"] == "LIVE_RPC",
                "Attempt provider/origin mismatch")
        require(sha(directory / "scan.before.sqlite3") == sha(directory / "scan.sqlite3") == DB_SHA,
                "Database changed during failed scan")
        state = snapshot(directory / "scan.sqlite3")
        require(state == read(directory / "state.before.json") == read(directory / "state.at-stop.json"),
                "State snapshot mismatch")
        require(state["state"]["cursor_number"] == BLOCK, "Checkpoint advanced")
        require(len(state["events"]) == len(state["outbox"]) == 1, "Original event/outbox count changed")
        require(state["outbox"][0]["emitted_at"] is not None, "Original output no longer acknowledged")
        packet = ww.History._checked(state["events"][0])
        require(packet["origin"] == "LIVE_RPC" and packet["source"] == PROVIDER, "Stored packet origin")
        require(packet["event"]["block_number"] == BLOCK and packet["event"]["amount"] == "300.000000",
                "Stored event changed")
        commands = read(directory / "commands.json")
        require([c["exit_code"] for c in commands] == [0, 2], "Unexpected command outcomes")
        require(all(c["fresh_process"] for c in commands), "Missing process provenance")
        require(commands[1]["argv"][0] == "scan" and "--start-block" not in commands[1]["argv"],
                "Attempt not resuming its checkpoint")
        require(commands[1]["argv"][-2:] == ["--batch-size", "1"], "Unbounded scan")
        require(read(directory / "result.json")["status"] == "INCOMPLETE", "False scan PASS")
        require((directory / "02-resume-one-block.stdout.jsonl").read_bytes() == b"", "Unexpected scan output")
        error = read(directory / "02-resume-one-block.stderr.txt")
        require(error == {"status": "error", "message": "RPC transport/JSON failure for eth_getLogs; checkpoint retained"},
                "Unexpected scan failure")
        records = sorted((directory / "02-resume-one-block-rpc").glob("*.request.json"))
        require(len(records) == 5, "Unexpected RPC attempt count")
        for number, path in enumerate(records, 1):
            capture = read(path)
            request = capture["request"]
            require(request["id"] == number and request["method"] in ww.READ_METHODS, "RPC sequence/method")
            require(capture["source_hostname"] == PROVIDER, "RPC provider changed")
            if capture["status"] == "ERROR":
                require(number == 5 and capture["error_type"] == "HTTPError", "Unexpected RPC failure")
                query = request["params"][0]
                address = packet["event"]["watched_address"]
                topic = "0x" + "0" * 24 + address[2:]
                require(request["method"] == "eth_getLogs" and query == {
                    "address": ww.USDC, "fromBlock": hex(BLOCK + 1), "toBlock": hex(BLOCK + 1),
                    "topics": [ww.TRANSFER, topic]}, "Failed request target mismatch")
                require(not path.with_name("005.response.json").exists(), "Unexpected failed response capture")
                failed_requests.append(request)
                totals["failed_requests"] += 1
                continue
            response_path = path.parent / capture["response_file"]
            response = read(response_path)
            require(capture["status"] == "RESPONSE_CAPTURED" and capture["http_status"] == 200,
                    "Unexpected response status")
            require(sha(response_path) == capture["response_sha256"] and
                    response_path.stat().st_size == capture["response_bytes"], "RPC response digest/length")
            require(response["id"] == request["id"] and response["jsonrpc"] == "2.0" and
                    "result" in response and "error" not in response, "RPC response envelope")
            if number == 1:
                require(response["result"] == "0x1", "Wrong chain")
            else:
                block = ww._block(response["result"])
                if number == 2:
                    require(request["params"] == ["finalized", False] and ww.quantity(block["number"]) >= BLOCK + 1,
                            "Finalized boundary did not cover target")
                elif number == 3:
                    require(request["params"] == [hex(BLOCK), False] and block["hash"] == state["state"]["cursor_hash"],
                            "Previous checkpoint response mismatch")
                else:
                    require(request["params"] == [hex(BLOCK + 1), False] and ww.quantity(block["number"]) == BLOCK + 1,
                            "Next block response mismatch")
            totals["responses"] += 1

    diagnostic = read(root / "http-diagnostic.json")
    require(diagnostic["request"] == failed_requests[0] == failed_requests[1], "Diagnostic changed request")
    require(diagnostic["source_hostname"] == PROVIDER and diagnostic["http_status"] == 403, "Diagnostic status")
    require(hashlib.sha256(diagnostic["response_text"].encode()).hexdigest() == diagnostic["response_sha256"],
            "Diagnostic body digest")
    error = json.loads(diagnostic["response_text"])
    require(error["error"]["code"] == -32602 and "personal token" in error["error"]["message"],
            "Diagnostic error not reproduced")
    require(read(root / "result.json")["status"] == "INCOMPLETE", "Overall result must remain incomplete")
    require(totals == {"responses": 8, "failed_requests": 2}, "RPC totals mismatch")
    print(json.dumps({"bundle_integrity": "PASS", "live_resume_status": "INCOMPLETE",
                      "source_head_sha": HEAD, "payload_files": len(files),
                      "successful_rpc_responses": 8, "failed_cli_rpc_requests": 2,
                      "diagnostic_http_status": 403, "database_bytes_unchanged": True,
                      "checkpoint_after_each_attempt": BLOCK}))


if __name__ == "__main__":
    main()
