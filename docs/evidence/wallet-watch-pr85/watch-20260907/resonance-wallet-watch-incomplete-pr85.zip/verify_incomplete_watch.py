#!/usr/bin/env python3
"""Verify the captured incomplete watch attempt using local bytes only."""
import argparse
from contextlib import contextmanager, redirect_stderr, redirect_stdout
import io
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
from urllib.error import URLError

sys.dont_write_bytecode = True
from run_bounded_watch_proof import HEAD, PROVIDER, require, sha, snapshot


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--bundle", type=Path, required=True)
    args = parser.parse_args()
    repo, root = args.repo.resolve(), args.bundle.resolve()
    manifest = read(root / "manifest.json")
    expected = set()
    for item in manifest["artifacts"]:
        path = (root / item["path"]).resolve()
        require(path.is_relative_to(root) and not (root / item["path"]).is_symlink(), "Unsafe manifest path")
        require(item["path"] not in expected, "Duplicate manifest path")
        expected.add(item["path"])
        require(sha(path) == item["sha256"] and path.stat().st_size == item["size_bytes"], "Payload digest/size mismatch")
    require(expected == {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()} - {"manifest.json"},
            "Manifest inventory mismatch")
    provenance, result = (read(root / name) for name in ("provenance.json", "result.json"))
    git = lambda *a: subprocess.check_output(["git", "-C", str(repo), *a], text=True).strip()
    require(git("rev-parse", "HEAD") == provenance["source_head_sha"] == provenance["final_source_head_sha"] == HEAD,
            "Source head mismatch")
    require(not git("status", "--porcelain", "--untracked-files=no") and not provenance["tracked_source_dirty"], "Dirty source")
    for path, digest in provenance["source_files"].items():
        require(sha(repo / path) == digest, "Source bytes mismatch")
    require(sha(root / "capture_cli.py") == provenance["capture_helper_sha256"] ==
            "60b7217675bc3fc5c7bb292cb38ccec20a7479c2e7a4aba893a4a8b809b7e460", "Capture helper changed")
    require(result["status"] == "INCOMPLETE", "This verifier applies only to the incomplete attempt")
    commands = read(root / "commands.json")
    require(len(commands) == 1, "Unexpected additional process")
    command = commands[0]
    phase = command["phase"]
    require(phase == "01-initial-watch" and command["fresh_process"] and command["argv"][0] == "watch",
            "Wrong command provenance")
    require(command["exit_code"] == 2 and command["iterations"] == 0 and command["outputs"] == [] and
            command["stop_reason"] == "NOT_REACHED", "Live scenario result mismatch")
    sys.path.insert(0, str(repo / "src"))
    from resonance_arbitrage_graph import wallet_watch as ww, wallet_watch_cli as cli
    responses, errors = 0, 0
    for directory in sorted(root.glob("*-rpc")):
        for index, path in enumerate(sorted(directory.glob("*.request.json")), 1):
            record = read(path)
            request = record["request"]
            require(record["source_hostname"] == PROVIDER and request["id"] == index and
                    request["jsonrpc"] == "2.0" and request["method"] in ww.READ_METHODS, "RPC origin/sequence/method")
            if record["status"] == "ERROR":
                errors += 1
                require(directory.name == phase + "-rpc" and index == 7 and record["error_type"] == "URLError",
                        "Unexpected failed request")
                require(request["method"] == "eth_getBlockByNumber" and request["params"] == ["0x18b96f9", False],
                        "Failed request changed")
                require("response_file" not in record and not (directory / "007.response.json").exists(),
                        "Failure has an unexpected response")
                continue
            require(record["status"] == "RESPONSE_CAPTURED" and record["http_status"] == 200, "RPC status")
            response_path = directory / record["response_file"]
            require(sha(response_path) == record["response_sha256"] and
                    response_path.stat().st_size == record["response_bytes"], "Response digest/size mismatch")
            response = read(response_path)
            require(response["jsonrpc"] == "2.0" and response["id"] == index and "result" in response and
                    "error" not in response, "RPC envelope")
            responses += 1
    require((responses, errors) == (9, 1), "RPC counts mismatch")
    live = snapshot(root / "watch.sqlite3")
    require(live == read(root / "state.at-stop.json"), "Database snapshot mismatch")
    require(live["events"] == live["outbox"] == [] and live["state"]["cursor_number"] is None and
            live["state"]["cursor_hash"] is None, "Partial scan persisted as completed")
    with sqlite3.connect(f"file:{root / 'watch.sqlite3'}?mode=ro", uri=True) as db:
        require(db.execute("PRAGMA integrity_check").fetchone()[0] == "ok", "SQLite integrity")
    captures = [read(p) for p in sorted((root / (phase + "-rpc")).glob("*.request.json"))]
    position = 0

    @contextmanager
    def offline_urlopen(request, timeout):
        nonlocal position
        require(position < len(captures), "Uncaptured RPC requested")
        capture = captures[position]
        position += 1
        require(request.full_url == "https://" + PROVIDER and json.loads(request.data) == capture["request"],
                "Replay request differs from captured request")
        if capture["status"] == "ERROR":
            raise URLError("recorded transport exception; original reason was not captured")
        with io.BytesIO((root / (phase + "-rpc") / capture["response_file"]).read_bytes()) as response:
            yield response

    def block_network(event, arguments):
        if event == "socket.connect":
            raise RuntimeError("Network disabled during offline verification")

    def no_sleep(seconds):
        raise RuntimeError("The captured attempt never reached a polling sleep")

    sys.addaudithook(block_network)
    ww.urlopen = offline_urlopen
    cli.time.sleep = no_sleep
    stdout, stderr = io.StringIO(), io.StringIO()
    with tempfile.TemporaryDirectory(prefix="incomplete-watch-offline-") as temporary:
        database = Path(temporary) / "replay.sqlite3"
        argv = command["argv"].copy()
        argv[argv.index("--db") + 1] = str(database)
        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli.main(argv)
        require(exit_code == command["exit_code"] == 2 and position == len(captures) == 7, "Replay termination mismatch")
        require(stdout.getvalue() == (root / (phase + ".stdout.jsonl")).read_text() == "", "Replay stdout mismatch")
        require(stderr.getvalue() == (root / (phase + ".stderr.txt")).read_text(), "Replay stderr mismatch")
        require(snapshot(database) == live, "Replay database state mismatch")
    print(json.dumps({"status": "PASS", "scope": "offline package integrity and abort-path replay only",
        "live_scenario_status": "INCOMPLETE", "source_head_sha": HEAD, "files_verified": len(expected),
        "rpc_responses_verified": responses, "failed_rpc_requests": errors, "offline_cli_executions": 1,
        "replayed_watch_exit_code": exit_code, "completed_watch_iterations": 0,
        "history_events": 0, "console_notifications": 0, "checkpoint": None,
        "limits": "Captured successful response bytes plus injected recorded exception class; original transport reason, runtime approval system and network were not replayed. No successful watch/restart claim."},
        sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
