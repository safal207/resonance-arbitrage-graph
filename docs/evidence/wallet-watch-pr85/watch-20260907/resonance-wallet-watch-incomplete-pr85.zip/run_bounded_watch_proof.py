#!/usr/bin/env python3
"""Two bounded real watch processes; one public provider, no source changes."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import sqlite3
import subprocess
import sys
import time

HEAD = "e2d644155b587da89b12116a9b94150c6e5d4837"
PROVIDER = "ethereum-rpc.publicnode.com"
sys.dont_write_bytecode = True


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def require(value, message):
    if not value:
        raise RuntimeError(message)


def snapshot(path):
    with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        return {"state": dict(db.execute("SELECT * FROM state WHERE id=1").fetchone()),
                "events": [dict(r) for r in db.execute("SELECT * FROM events ORDER BY event_id")],
                "outbox": [dict(r) for r in db.execute("SELECT * FROM outbox ORDER BY event_id")]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--capture-helper", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    repo, helper, out = args.repo.resolve(), args.capture_helper.resolve(), args.out.resolve()
    git = lambda *a: subprocess.check_output(["git", "-C", str(repo), *a], text=True).strip()
    require(git("rev-parse", "HEAD") == HEAD and not git("status", "--porcelain", "--untracked-files=no"),
            "Expected clean pinned source")
    require(helper.is_file(), "Capture helper must be materialized before starting an attempt")
    require(sha(helper) == "60b7217675bc3fc5c7bb292cb38ccec20a7479c2e7a4aba893a4a8b809b7e460",
            "Capture helper differs from the published live-proof helper")
    out.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(helper, out / "capture_cli.py")
    shutil.copyfile(Path(__file__).resolve(), out / "run_bounded_watch_proof.py")
    sys.path.insert(0, str(repo / "src"))
    sys.path.insert(0, str(out))
    from resonance_arbitrage_graph import wallet_watch as ww
    from capture_cli import install_capture
    require(ww.DEFAULT_RPC == "https://" + PROVIDER, "Provider changed")
    provenance = {"source_head_sha": HEAD, "source_hostname": PROVIDER, "origin": "LIVE_RPC",
        "started_at": now(), "python": sys.version, "new_database": True,
        "capture_helper_sha256": sha(helper), "poll_seconds": 15, "batch_size": 1,
        "initial_watch_deadline_seconds": 240, "resumed_watch_deadline_seconds": 480,
        "termination": "parent sends SIGINT after complete CLI scan/caught_up output; expected CLI exit 130",
        "source_files": {p: sha(repo / p) for p in (
            "src/resonance_arbitrage_graph/wallet_watch.py",
            "src/resonance_arbitrage_graph/wallet_watch_cli.py")}}
    save(out / "provenance.json", provenance)
    db = out / "watch.sqlite3"
    commands = []
    result = {"status": "INCOMPLETE", "source_head_sha": HEAD,
              "scope": "bounded watch loop plus controlled process restart, single provider"}

    def watch(phase, argv, deadline_seconds, predicate):
        started = now()
        trace = {"phase": phase, "argv": argv, "fresh_process": True, "started_at": started,
                 "deadline_seconds": deadline_seconds, "outputs": [], "stop_reason": "NOT_REACHED"}
        command = [sys.executable, "-B", str(out / "capture_cli.py"), "--repo", str(repo),
                   "--out", str(out), "--child", "--phase", phase, "--", *argv]
        print(json.dumps({"phase": phase, "status": "STARTED", "at": started}), flush=True)
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
        selector = selectors.DefaultSelector()
        selector.register(process.stdout, selectors.EVENT_READ)
        outputs, summaries = [], []
        deadline = time.monotonic() + deadline_seconds
        signalled_at = None
        pending_bytes = b""
        with (out / f"{phase}.stdout.jsonl").open("wb") as stdout:
            try:
                while process.poll() is None:
                    if signalled_at is None and time.monotonic() >= deadline:
                        trace["stop_reason"] = "DEADLINE"
                        trace["signal_sent_at"] = now()
                        process.send_signal(signal.SIGINT)
                        signalled_at = time.monotonic()
                    if signalled_at is not None and time.monotonic() - signalled_at > 10:
                        process.kill()
                        trace["forced_kill"] = True
                    for key, _ in selector.select(timeout=0.5):
                        chunk = os.read(key.fd, 65536)
                        if not chunk:
                            selector.unregister(key.fileobj)
                            continue
                        stdout.write(chunk)
                        stdout.flush()
                        pending_bytes += chunk
                        lines = pending_bytes.split(b"\n")
                        pending_bytes = lines.pop()
                        for line in lines:
                            value = json.loads(line)
                            outputs.append(value)
                            trace["outputs"].append({"received_at": now(), "record": value})
                            if value.get("status") in ("scanned", "caught_up"):
                                summaries.append(value)
                                print(json.dumps({"phase": phase, "iteration": len(summaries), **value}), flush=True)
                                if signalled_at is None and predicate(summaries):
                                    trace["stop_reason"] = "CONDITION_REACHED"
                                    # The real CLI enters its 15-second polling sleep
                                    # after the flushed summary and local housekeeping.
                                    time.sleep(0.1)
                                    trace["signal_sent_at"] = now()
                                    process.send_signal(signal.SIGINT)
                                    signalled_at = time.monotonic()
                remaining, stderr = process.communicate(timeout=5)
                stdout.write(remaining)
                require(not remaining.strip() and not pending_bytes.strip(), "Unexpected untracked stdout after stop")
            finally:
                selector.close()
                if process.poll() is None:
                    process.kill()
                    process.wait()
        (out / f"{phase}.stderr.txt").write_bytes(stderr)
        trace.update(finished_at=now(), exit_code=process.returncode, iterations=len(summaries))
        commands.append(trace)
        save(out / "commands.json", commands)
        require(trace["stop_reason"] == "CONDITION_REACHED" and process.returncode == 130 and not stderr,
                f"{phase} did not complete the bounded condition with controlled SIGINT")
        require(all(json.loads(p.read_text())["status"] == "RESPONSE_CAPTURED"
                    for p in (out / (phase + "-rpc")).glob("*.request.json")),
                "RPC capture unfinished at controlled stop")
        return outputs, summaries

    def local(phase, argv):
        started = now()
        completed = subprocess.run([sys.executable, "-B", str(out / "capture_cli.py"),
            "--repo", str(repo), "--out", str(out), "--child", "--phase", phase, "--", *argv],
            capture_output=True, text=True, timeout=30)
        (out / f"{phase}.stdout.jsonl").write_text(completed.stdout)
        (out / f"{phase}.stderr.txt").write_text(completed.stderr)
        commands.append({"phase": phase, "argv": argv, "fresh_process": True,
            "started_at": started, "finished_at": now(), "exit_code": completed.returncode})
        save(out / "commands.json", commands)
        require(completed.returncode == 0, "Local history/output verification failed")
        return [json.loads(line) for line in completed.stdout.splitlines() if line]

    try:
        install_capture(ww, out / "00-discovery-rpc")
        rpc = ww.Rpc(ww.DEFAULT_RPC)
        require(rpc.call("eth_chainId", []) == "0x1", "Wrong chain")
        finalized = ww._block(rpc.call("eth_getBlockByNumber", ["finalized", False]))
        initial_finalized = ww.quantity(finalized["number"])
        first = initial_finalized - 1
        logs = rpc.call("eth_getLogs", [{"address": ww.USDC, "fromBlock": hex(first),
            "toBlock": hex(first), "topics": [ww.TRANSFER]}])
        require(isinstance(logs, list) and len(logs) <= 2000, "Discovery result unbounded")
        decoded = [ww.decode_log(log) for log in logs]
        require(all(e["block_number"] == first for e in decoded), "Discovery range mismatch")
        selected = next(({**e, "watched_address": e["to_address"]} for e in sorted(decoded, key=lambda e: e["log_index"])
            if int(e["amount_units"]) >= 1_000_000 and e["to_address"] != "0x" + "00" * 20 and
            sum(e["to_address"] in (other["from_address"], other["to_address"]) for other in decoded) == 1), None)
        require(selected is not None, "No qualifying transfer in one discovery block")
        save(out / "selection.json", {"event": selected, "first_block": first,
            "initial_finalized": finalized, "selected_at": now(), "ownership_inferred": False,
            "selection_rule": "lowest-log-index >=1 USDC transfer with nonzero recipient appearing once in the preceding finalized block's returned USDC logs",
            "discovery_log_count": len(logs)})
        print(json.dumps({"phase": "selected", "initial_finalized": initial_finalized, "event": selected}), flush=True)
        common = ["--address", selected["watched_address"], "--db", str(db), "--min-usdc", "1",
            "--batch-size", "1", "--poll-seconds", "15", "--rpc-url", ww.DEFAULT_RPC]
        initial, initial_summaries = watch("01-initial-watch", ["watch", *common, "--start-block", str(first)],
            240, lambda rows: len(rows) >= 2)
        require(len(initial_summaries) == 2 and all(r["status"] == "scanned" for r in initial_summaries),
                "Expected two initial scanned iterations")
        require(initial_summaries[0]["from_block"] == initial_summaries[0]["through_block"] == first and
                initial_summaries[1]["from_block"] == initial_summaries[1]["through_block"] == initial_finalized,
                "Initial watch range mismatch")
        require(initial_summaries[0]["new_events"] == initial_summaries[0]["console_notifications"] == 1,
                "First watch iteration missed the qualifying event")
        old = next(r for r in initial if r.get("type") == "transfer_notification" and
            r["tx_hash"] == selected["tx_hash"] and r["log_index"] == selected["log_index"])
        before = snapshot(db)
        save(out / "state.before-restart.json", before)
        shutil.copyfile(db, out / "watch.before-restart.sqlite3")
        history_before = local("02-history-before-restart", ["history", "--db", str(db)])
        resumed, resumed_summaries = watch("03-resumed-watch", ["watch", *common], 480,
            lambda rows: len(rows) >= 2 and any(r["status"] == "scanned" and
                r["through_block"] > initial_finalized for r in rows))
        after = snapshot(db)
        save(out / "state.after-restart.json", after)
        require(after["state"]["config"] == before["state"]["config"], "Configuration changed")
        require(after["state"]["cursor_number"] > initial_finalized, "Watch did not reach a newly finalized block")
        old_ids = {r["event_id"] for r in before["events"]}
        require([r for r in after["events"] if r["event_id"] in old_ids] == before["events"], "Existing event packets changed")
        require([r for r in after["outbox"] if r["event_id"] in old_ids] == before["outbox"], "Acknowledgements changed")
        notices = [r for r in initial + resumed if r.get("type") == "transfer_notification"]
        require(len(notices) == len({r["event_id"] for r in notices}), "A notification event ID repeated")
        require(all(r.get("event_id") not in old_ids for r in resumed), "Restart repeated acknowledged output")
        all_summaries = initial_summaries + resumed_summaries
        scanned = [r for r in all_summaries if r["status"] == "scanned"]
        require([r["from_block"] for r in scanned] == list(range(first, after["state"]["cursor_number"] + 1)),
                "Skipped or repeated scan range")
        require(all(r["from_block"] == r["through_block"] for r in scanned), "Scan escaped one-block bound")
        require(sum(r["new_events"] for r in all_summaries) == len(after["events"]) and
                sum(r["console_notifications"] for r in all_summaries) == len(notices), "Counts mismatch")
        history_after = local("04-history-after-restart", ["history", "--db", str(db)])
        pending = local("05-pending-notifications", ["notifications", "--db", str(db)])
        require(pending == [] and snapshot(db) == after, "Unexpected pending output/state change")
        result.update(status="PASS", event={k: v for k, v in old.items() if k not in ("type", "evidence_sha256", "origin")},
            initial_finalized=initial_finalized, first_block=first,
            checkpoint_before_restart=[before["state"]["cursor_number"], before["state"]["cursor_hash"]],
            checkpoint_after_restart=[after["state"]["cursor_number"], after["state"]["cursor_hash"]],
            initial_watch_iterations=len(initial_summaries), resumed_watch_iterations=len(resumed_summaries),
            caught_up_iterations=sum(r["status"] == "caught_up" for r in all_summaries),
            scanned_blocks=len(scanned), history_before_restart=len(history_before), final_history_events=len(history_after),
            total_console_notifications=len(notices), duplicate_console_notifications=0,
            new_events_after_restart=len(after["events"]) - len(before["events"]),
            pending_notifications=0, previous_packets_and_acknowledgements_unchanged=True,
            newly_finalized_progress_observed=True, watch_exit_codes=[130, 130],
            scope="bounded real watch loop and controlled restart; not a long-running service certification")
    except Exception as error:
        result.update(status="INCOMPLETE", error_type=type(error).__name__, error=str(error))
        if db.exists():
            save(out / "state.at-stop.json", snapshot(db))
    finally:
        provenance["finished_at"] = now()
        provenance["final_source_head_sha"] = git("rev-parse", "HEAD")
        provenance["tracked_source_dirty"] = bool(git("status", "--porcelain", "--untracked-files=no"))
        if provenance["final_source_head_sha"] != HEAD or provenance["tracked_source_dirty"]:
            result["status"] = "HOLD"
        save(out / "provenance.json", provenance)
        save(out / "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
