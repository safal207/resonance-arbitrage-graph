#!/usr/bin/env python3
"""Verify a bounded watch capture; re-execute its CLI loops without network."""
import argparse
from contextlib import contextmanager
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
from run_bounded_watch_proof import HEAD, PROVIDER, require, sha, snapshot

PHASES = ("01-initial-watch", "03-resumed-watch")


def read(path):
    return json.loads(path.read_text())


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def normalized_state(state, ww):
    packets = [ww.History._checked(row) for row in state["events"]]
    return {"state": state["state"],
            "packets": [{k: v for k, v in p.items() if k != "observed_at"} for p in packets],
            "outbox": [{"event_id": r["event_id"], "acknowledged": r["emitted_at"] is not None}
                       for r in state["outbox"]]}


def child(root, repo, phase, database):
    sys.path.insert(0, str(repo / "src"))
    from resonance_arbitrage_graph import wallet_watch as ww, wallet_watch_cli as cli
    captures = [read(p) for p in sorted((root / (phase + "-rpc")).glob("*.request.json"))]
    command = next(c for c in read(root / "commands.json") if c["phase"] == phase)
    position, sleeps = 0, 0

    @contextmanager
    def offline_urlopen(request, timeout):
        nonlocal position
        require(position < len(captures), "Uncaptured RPC requested")
        capture = captures[position]
        position += 1
        require(request.full_url == ww.DEFAULT_RPC and json.loads(request.data) == capture["request"],
                "Offline request differs from captured live request")
        with io.BytesIO((root / (phase + "-rpc") / capture["response_file"]).read_bytes()) as response:
            yield response

    def offline_sleep(seconds):
        nonlocal sleeps
        require(seconds == 15, "Polling interval changed")
        sleeps += 1
        if position == len(captures):
            raise KeyboardInterrupt

    ww.urlopen = offline_urlopen
    cli.time.sleep = offline_sleep
    argv = command["argv"].copy()
    argv[argv.index("--db") + 1] = str(database)
    exit_code = cli.main(argv)
    require(exit_code == 130 and position == len(captures) and sleeps == command["iterations"],
            "Offline loop did not consume the complete trace and controlled stop")
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--phase", choices=PHASES)
    parser.add_argument("--db", type=Path)
    args = parser.parse_args()
    root, repo = args.bundle.resolve(), args.repo.resolve()
    if args.phase:
        require(args.db is not None, "Temporary replay DB missing")
        return child(root, repo, args.phase, args.db.resolve())

    manifest = read(root / "manifest.json")
    expected = set()
    for item in manifest["artifacts"]:
        path = (root / item["path"]).resolve()
        require(path.is_relative_to(root) and not (root / item["path"]).is_symlink(), "Unsafe manifest path")
        require(item["path"] not in expected, "Duplicate manifest path")
        expected.add(item["path"])
        require(sha(path) == item["sha256"] and path.stat().st_size == item["size_bytes"], "Payload digest/size")
    require(expected == {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()} - {"manifest.json"},
            "Manifest inventory mismatch")
    provenance, result, selection = (read(root / name) for name in ("provenance.json", "result.json", "selection.json"))
    git = lambda *a: subprocess.check_output(["git", "-C", str(repo), *a], text=True).strip()
    require(git("rev-parse", "HEAD") == provenance["source_head_sha"] == provenance["final_source_head_sha"] == HEAD,
            "Source head mismatch")
    require(not git("status", "--porcelain", "--untracked-files=no") and not provenance["tracked_source_dirty"], "Dirty source")
    for path, digest in provenance["source_files"].items():
        require(sha(repo / path) == digest, "Source bytes mismatch")
    require(sha(root / "capture_cli.py") == provenance["capture_helper_sha256"] ==
            "60b7217675bc3fc5c7bb292cb38ccec20a7479c2e7a4aba893a4a8b809b7e460", "Capture helper changed")
    require(result["status"] == "PASS", "This verifier expects a completed bounded scenario")
    sys.path.insert(0, str(repo / "src"))
    from resonance_arbitrage_graph import wallet_watch as ww
    before, after = snapshot(root / "watch.before-restart.sqlite3"), snapshot(root / "watch.sqlite3")
    require(before == read(root / "state.before-restart.json") and after == read(root / "state.after-restart.json"),
            "DB snapshots disagree")
    initial_finalized = ww.quantity(selection["initial_finalized"]["number"])
    require(before["state"]["cursor_number"] == initial_finalized and
            after["state"]["cursor_number"] > initial_finalized, "No post-restart newly finalized progress")
    require(before["state"]["config"] == after["state"]["config"], "Configuration changed")
    prior_ids = {r["event_id"] for r in before["events"]}
    require([r for r in after["events"] if r["event_id"] in prior_ids] == before["events"], "Prior evidence changed")
    require([r for r in after["outbox"] if r["event_id"] in prior_ids] == before["outbox"], "Prior acknowledgements changed")
    for state in (before, after):
        for row in state["events"]:
            packet = ww.History._checked(row)
            require(packet["origin"] == "LIVE_RPC" and packet["source"] == PROVIDER, "Wrong packet origin")
        require(all(r["emitted_at"] is not None for r in state["outbox"]), "Pending notification")
    require(len(after["events"]) == result["final_history_events"] and
            len(after["outbox"]) == result["total_console_notifications"], "Reported counts differ")
    commands = read(root / "commands.json")
    require(len(commands) == 5 and all(c["fresh_process"] for c in commands), "Process provenance")
    for command in commands:
        phase = command["phase"]
        if phase in PHASES:
            require(command["exit_code"] == 130 and command["stop_reason"] == "CONDITION_REACHED" and
                    not command.get("forced_kill"), "Unexpected watch termination")
            require(command["iterations"] >= 2, "Watch did not loop")
            require([r["record"] for r in command["outputs"]] == records(root / (phase + ".stdout.jsonl")),
                    "Timestamped stdout trace mismatch")
            require(command["argv"][0] == "watch", "Wrong CLI command")
            if phase == PHASES[1]:
                require("--start-block" not in command["argv"], "Restart rewrote start block")
        else:
            require(command["exit_code"] == 0, "Local history verification failed")
        require((root / (phase + ".stderr.txt")).read_bytes() == b"", "Unexpected stderr")
    all_output = sum((records(root / (phase + ".stdout.jsonl")) for phase in PHASES), [])
    notices = [r for r in all_output if r.get("type") == "transfer_notification"]
    require(len(notices) == len({r["event_id"] for r in notices}) == result["total_console_notifications"], "Duplicate output")
    resumed = records(root / (PHASES[1] + ".stdout.jsonl"))
    require(all(r.get("event_id") not in prior_ids for r in resumed), "Restart repeated prior notification")
    scans = [r for r in all_output if r.get("status") == "scanned"]
    require([r["from_block"] for r in scans] == list(range(selection["first_block"], after["state"]["cursor_number"] + 1)) and
            all(r["from_block"] == r["through_block"] for r in scans), "Skipped/repeated block range")
    require((root / "05-pending-notifications.stdout.jsonl").read_bytes() == b"", "Pending stdout")
    count = 0
    finalized_heights = []
    for directory in sorted(root.glob("*-rpc")):
        for index, path in enumerate(sorted(directory.glob("*.request.json")), 1):
            record = read(path)
            require(record["source_hostname"] == PROVIDER and record["status"] == "RESPONSE_CAPTURED" and
                    record["http_status"] == 200, "Unfinished/failed RPC")
            request = record["request"]
            require(request["id"] == index and request["method"] in ww.READ_METHODS, "RPC method/sequence")
            path = directory / record["response_file"]
            require(sha(path) == record["response_sha256"] and path.stat().st_size == record["response_bytes"], "RPC binding")
            response = read(path)
            require(response["jsonrpc"] == "2.0" and response["id"] == index and "error" not in response and
                    "result" in response, "RPC envelope")
            if request["method"] == "eth_getBlockByNumber" and request["params"] == ["finalized", False]:
                finalized_heights.append(ww.quantity(response["result"]["number"]))
            count += 1
    require(max(finalized_heights) > initial_finalized, "Provider finalized boundary did not advance")

    with tempfile.TemporaryDirectory(prefix="bounded-watch-offline-") as temporary:
        database = Path(temporary) / "replay.sqlite3"
        for phase, live_state in zip(PHASES, (before, after)):
            completed = subprocess.run([sys.executable, "-B", str(Path(__file__).resolve()), "--repo", str(repo),
                "--bundle", str(root), "--phase", phase, "--db", str(database)], capture_output=True, text=True, timeout=30)
            require(completed.returncode == 0, f"Offline watch replay failed: {completed.stderr}")
            reproduced = [json.loads(line) for line in completed.stdout.splitlines() if line]
            normalize = lambda rows: [{k: v for k, v in r.items() if k != "evidence_sha256"} for r in rows]
            require(normalize(reproduced) == normalize(records(root / (phase + ".stdout.jsonl"))), "Offline output mismatch")
            require(normalized_state(snapshot(database), ww) == normalized_state(live_state, ww), "Offline durable state mismatch")
    print(json.dumps({"status": "PASS", "source_head_sha": HEAD, "files_verified": len(expected),
        "rpc_responses_verified": count, "offline_watch_processes": 2,
        "watch_exit_codes": [130, 130], "initial_finalized": initial_finalized,
        "final_checkpoint": after["state"]["cursor_number"], "history_events": len(after["events"]),
        "console_notifications": len(notices), "duplicate_console_notifications": 0,
        "scope": "offline replay of recorded watch loops; polling sleeps omitted and controlled interrupt reproduced; wall-clock metadata normalized; no new live observation or timing claim"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
