#!/usr/bin/env python3
"""Bounded fresh two-block live proof; old archival proof remains incomplete."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys

HEAD = "e2d644155b587da89b12116a9b94150c6e5d4837"
PROVIDER = "ethereum-rpc.publicnode.com"


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def require(value, message):
    if not value:
        raise RuntimeError(message)


def snapshot(path):
    with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        return {
            "state": dict(db.execute("SELECT * FROM state WHERE id=1").fetchone()),
            "events": [dict(r) for r in db.execute("SELECT * FROM events ORDER BY event_id")],
            "outbox": [dict(r) for r in db.execute("SELECT * FROM outbox ORDER BY event_id")],
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--capture-helper", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    repo, helper, out = args.repo.resolve(), args.capture_helper.resolve(), args.out.resolve()
    git = lambda *a: subprocess.check_output(["git", "-C", str(repo), *a], text=True).strip()
    require(git("rev-parse", "HEAD") == HEAD, "Wrong source head")
    require(not git("status", "--porcelain", "--untracked-files=no"), "Tracked source changed")
    out.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(helper, out / "capture_cli.py")
    shutil.copyfile(Path(__file__).resolve(), out / "run_recent_resume_proof.py")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(repo / "src"))
    sys.path.insert(0, str(out))
    from resonance_arbitrage_graph import wallet_watch as ww
    from capture_cli import install_capture
    require(ww.DEFAULT_RPC == "https://" + PROVIDER, "Default provider changed")
    provenance = {"source_head_sha": HEAD, "source_hostname": PROVIDER, "origin": "LIVE_RPC",
                  "started_at": now(), "python": sys.version, "new_database": True,
                  "capture_helper_sha256": sha(helper),
                  "capture_helper_baseline_evidence_commit": "dc445bfac231ba6a3bcaac9c6388805d163c3c75",
                  "capture": "original urllib read wrapper; raw response bytes unchanged",
                  "scope": "new public address selected from one recent finalized block, then next-block resume",
                  "earlier_archive_attempt": {"status": "INCOMPLETE", "checkpoint": 25919603,
                      "evidence_commit": "4cc66497c2e32221d3a726cd78b247cda57873b1",
                      "not_used_or_modified": True},
                  "source_files": {p: sha(repo / p) for p in (
                      "src/resonance_arbitrage_graph/wallet_watch.py",
                      "src/resonance_arbitrage_graph/wallet_watch_cli.py")}}
    save(out / "provenance.json", provenance)
    result = {"status": "INCOMPLETE", "source_head_sha": HEAD,
              "scope": "new recent two-block scenario, one provider",
              "earlier_archive_attempt_status": "INCOMPLETE"}
    commands = []
    db = out / "scan.sqlite3"

    def run(phase, argv):
        started = now()
        print(json.dumps({"phase": phase, "status": "STARTED", "at": started}), flush=True)
        try:
            completed = subprocess.run([sys.executable, str(out / "capture_cli.py"),
                "--repo", str(repo), "--out", str(out), "--child", "--phase", phase, "--", *argv],
                capture_output=True, timeout=180)
            stdout, stderr, code = completed.stdout, completed.stderr, completed.returncode
        except subprocess.TimeoutExpired as error:
            stdout, stderr, code = error.stdout or b"", error.stderr or b"", 124
        (out / f"{phase}.stdout.jsonl").write_bytes(stdout)
        (out / f"{phase}.stderr.txt").write_bytes(stderr)
        commands.append({"phase": phase, "argv": argv, "fresh_process": True,
                         "started_at": started, "finished_at": now(), "exit_code": code})
        save(out / "commands.json", commands)
        require(code == 0, f"{phase} failed; see retained stderr")
        rows = [json.loads(line) for line in stdout.splitlines() if line]
        print(json.dumps({"phase": phase, "status": "DONE", "output_records": len(rows)}), flush=True)
        return rows

    try:
        install_capture(ww, out / "00-discovery-rpc")
        rpc = ww.Rpc(ww.DEFAULT_RPC)
        require(rpc.call("eth_chainId", []) == "0x1", "Wrong chain")
        finalized = ww._block(rpc.call("eth_getBlockByNumber", ["finalized", False]))
        target = ww.quantity(finalized["number"])
        first = target - 1
        require(first >= 0, "Invalid finalized height")
        logs = rpc.call("eth_getLogs", [{"address": ww.USDC, "fromBlock": hex(first),
            "toBlock": hex(first), "topics": [ww.TRANSFER]}])
        require(isinstance(logs, list) and len(logs) <= 2000, "Missing or unbounded discovery logs")
        decoded = [ww.decode_log(log) for log in logs]
        require(all(event["block_number"] == first for event in decoded), "Discovery escaped one block")
        selected = None
        for event in sorted(decoded, key=lambda e: e["log_index"]):
            address = event["to_address"]
            count = sum(address in (e["from_address"], e["to_address"]) for e in decoded)
            if address != "0x" + "00" * 20 and int(event["amount_units"]) >= 1_000_000 and count == 1:
                selected = {**event, "watched_address": address}
                break
        require(selected is not None, "No qualifying transfer in the one discovery block")
        save(out / "selection.json", {"event": selected, "discovery_log_count": len(logs),
            "first_block": first, "resume_block": target, "discovery_finalized": finalized,
            "selection_rule": "lowest-log-index transfer >=1 USDC with a nonzero recipient occurring once in this block's provider-returned USDC logs",
            "selected_at": now(), "ownership_inferred": False})
        print(json.dumps({"phase": "selected", "first_block": first, "resume_block": target,
                          "event": selected}), flush=True)
        common = ["--address", selected["watched_address"], "--min-usdc", "1", "--db", str(db)]
        initial = run("01-initial-scan", ["scan", *common, "--start-block", str(first), "--batch-size", "1"])
        require(len(initial) == 2 and initial[0]["type"] == "transfer_notification" and
                initial[-1]["new_events"] == initial[-1]["console_notifications"] == 1,
                "Fresh scan did not emit exactly one qualifying transfer")
        require(initial[-1]["from_block"] == initial[-1]["through_block"] == first, "Initial range mismatch")
        old_id = initial[0]["event_id"]
        require(initial[0]["tx_hash"] == selected["tx_hash"] and
                initial[0]["log_index"] == selected["log_index"], "Initial event differs from selection")
        before = snapshot(db)
        save(out / "state.before-resume.json", before)
        shutil.copyfile(db, out / "scan.before-resume.sqlite3")
        require(before["state"]["cursor_number"] == first, "Initial checkpoint missing")
        history_before = run("02-history-before-resume", ["history", "--db", str(db)])
        require(len(history_before) == 1 and history_before[0]["event"]["event_id"] == old_id,
                "Initial history mismatch")
        resumed = run("03-resumed-scan", ["scan", *common, "--batch-size", "1"])
        summary = resumed[-1]
        require(summary["status"] == "scanned" and summary["from_block"] == summary["through_block"] == target,
                "Resume failed to advance exactly one block")
        notices = [row for row in resumed if row.get("type") == "transfer_notification"]
        require(all(row["event_id"] != old_id for row in notices), "Original transfer emitted on resume")
        after = snapshot(db)
        save(out / "state.after-resume.json", after)
        require(after["state"]["cursor_number"] == target and
                after["state"]["cursor_hash"] == finalized["hash"], "Resumed checkpoint mismatch")
        require(after["state"]["config"] == before["state"]["config"], "Watch configuration changed")
        require([r for r in after["events"] if r["event_id"] == old_id] == before["events"],
                "Original event evidence changed")
        require([r for r in after["outbox"] if r["event_id"] == old_id] == before["outbox"],
                "Original notification acknowledgement changed")
        require(len(after["events"]) == 1 + summary["new_events"] and
                len(notices) == summary["console_notifications"], "Resumed event/output count mismatch")
        history_after = run("04-history-after-resume", ["history", "--db", str(db)])
        replay = run("05-restart-original-transaction", ["transaction", *common, "--tx", selected["tx_hash"]])
        require(len(replay) == 1 and replay[0]["new_events"] == replay[0]["console_notifications"] == 0,
                "Ordinary transaction replay duplicated event/output")
        final_history = run("06-history-after-replay", ["history", "--db", str(db)])
        require(final_history == history_after, "History changed after transaction replay")
        pending = run("07-pending-notifications", ["notifications", "--db", str(db)])
        require(pending == [], "Pending output remained")
        final = snapshot(db)
        save(out / "state.final.json", final)
        require(final == after, "Replay altered durable state")
        result.update(status="PASS", event=history_before[0]["event"], initial_scan=initial[-1],
            resumed_scan=summary, transaction_replay=replay[0],
            checkpoint_before=[first, before["state"]["cursor_hash"]],
            checkpoint_after=[target, after["state"]["cursor_hash"]],
            original_event_and_outbox_unchanged=True, original_event_notifications_on_resume=0,
            final_history_events=len(final_history), pending_notifications=0,
            fresh_cli_processes=len(commands))
    except Exception as error:
        result.update(status="INCOMPLETE", error_type=type(error).__name__, error=str(error))
        if db.exists():
            save(out / "state.at-stop.json", snapshot(db))
    finally:
        provenance["finished_at"] = now()
        provenance["final_source_head_sha"] = git("rev-parse", "HEAD")
        provenance["tracked_source_dirty"] = bool(git("status", "--porcelain", "--untracked-files=no"))
        if provenance["final_source_head_sha"] != HEAD or provenance["tracked_source_dirty"]:
            result["status"] = "HOLD"
        save(out / "provenance.json", provenance)
        save(out / "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
