#!/usr/bin/env python3
"""Verify retained live evidence and re-execute three CLI paths offline."""
import argparse
from contextlib import contextmanager
import hashlib
import io
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
HEAD = "e2d644155b587da89b12116a9b94150c6e5d4837"
PROVIDER = "ethereum-rpc.publicnode.com"
LIVE_PHASES = ("01-initial-scan", "03-resumed-scan", "05-restart-original-transaction")


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def snapshot(path):
    with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        require(db.execute("PRAGMA integrity_check").fetchone()[0] == "ok", "SQLite integrity")
        return {"state": dict(db.execute("SELECT * FROM state WHERE id=1").fetchone()),
                "events": [dict(r) for r in db.execute("SELECT * FROM events ORDER BY event_id")],
                "outbox": [dict(r) for r in db.execute("SELECT * FROM outbox ORDER BY event_id")]}


def normalized_output(rows):
    # Packet digests include wall-clock observed_at. Event projections and summaries
    # must still match exactly; actual packet digests are checked separately.
    return [{key: value for key, value in row.items() if key != "evidence_sha256"} for row in rows]


def normalized_state(state, ww):
    packets = []
    for row in state["events"]:
        packet = ww.History._checked(row)
        packets.append({key: value for key, value in packet.items() if key != "observed_at"})
    return {"state": state["state"], "packets": packets,
            "outbox": [{"event_id": row["event_id"], "acknowledged": row["emitted_at"] is not None}
                       for row in state["outbox"]]}


def replay_child(root, repo, phase, database):
    sys.path.insert(0, str(repo / "src"))
    from resonance_arbitrage_graph import wallet_watch as ww, wallet_watch_cli as cli
    captures = [read(p) for p in sorted((root / (phase + "-rpc")).glob("*.request.json"))]
    position = 0

    @contextmanager
    def offline_urlopen(request, timeout):
        nonlocal position
        require(position < len(captures), "Replay requested an uncaptured RPC")
        capture = captures[position]
        position += 1
        require(request.full_url == ww.DEFAULT_RPC, "Replay changed endpoint")
        require(json.loads(request.data) == capture["request"], "Replay request differs from live capture")
        raw = (root / (phase + "-rpc") / capture["response_file"]).read_bytes()
        with io.BytesIO(raw) as response:
            yield response

    # Every RPC read is intercepted. No network operation is delegated.
    ww.urlopen = offline_urlopen
    command = next(c for c in read(root / "commands.json") if c["phase"] == phase)
    argv = command["argv"].copy()
    argv[argv.index("--db") + 1] = str(database)
    code = cli.main([*argv, "--rpc-url", ww.DEFAULT_RPC])
    require(code == 0 and position == len(captures), "Replay did not consume the exact successful trace")
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--bundle", required=True, type=Path)
    parser.add_argument("--replay-phase", choices=LIVE_PHASES)
    parser.add_argument("--replay-db", type=Path)
    args = parser.parse_args()
    root, repo = args.bundle.resolve(), args.repo.resolve()
    if args.replay_phase:
        require(args.replay_db is not None, "Replay needs a temporary DB")
        return replay_child(root, repo, args.replay_phase, args.replay_db.resolve())

    manifest = read(root / "manifest.json")
    expected = set()
    for item in manifest["artifacts"]:
        path = (root / item["path"]).resolve()
        require(path.is_relative_to(root) and not (root / item["path"]).is_symlink(), "Unsafe artifact path")
        require(item["path"] not in expected, "Duplicate manifest path")
        expected.add(item["path"])
        require(path.stat().st_size == item["size_bytes"] and sha(path) == item["sha256"], "Artifact digest/size")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()} - {"manifest.json"}
    require(actual == expected, "Payload inventory mismatch")
    provenance = read(root / "provenance.json")
    git = lambda *a: subprocess.check_output(["git", "-C", str(repo), *a], text=True).strip()
    require(git("rev-parse", "HEAD") == provenance["source_head_sha"] ==
            provenance["final_source_head_sha"] == HEAD, "Wrong source head")
    require(not git("status", "--porcelain", "--untracked-files=no") and
            provenance["tracked_source_dirty"] is False, "Dirty source")
    require(provenance["source_hostname"] == PROVIDER and provenance["origin"] == "LIVE_RPC", "Provenance origin")
    for name, digest in provenance["source_files"].items():
        require(sha(repo / name) == digest, "Source digest mismatch")
    require(sha(root / "capture_cli.py") == provenance["capture_helper_sha256"], "Capture helper changed")
    sys.path.insert(0, str(repo / "src"))
    from resonance_arbitrage_graph import wallet_watch as ww

    result, selection = read(root / "result.json"), read(root / "selection.json")
    require(result["status"] == "PASS" and result["earlier_archive_attempt_status"] == "INCOMPLETE", "Claim scope mismatch")
    first, target = selection["first_block"], selection["resume_block"]
    require(target == first + 1, "Not consecutive blocks")
    require(selection["ownership_inferred"] is False, "Unexpected ownership inference")
    before, final = snapshot(root / "scan.before-resume.sqlite3"), snapshot(root / "scan.sqlite3")
    require(before == read(root / "state.before-resume.json"), "Starting snapshot mismatch")
    require(final == read(root / "state.after-resume.json") == read(root / "state.final.json"), "Final snapshot mismatch")
    require(before["state"]["cursor_number"] == first and final["state"]["cursor_number"] == target, "Checkpoint mismatch")
    require(before["state"]["config"] == final["state"]["config"], "Configuration changed")
    require(len(before["events"]) == len(before["outbox"]) == 1, "Initial event count")
    old_id = before["events"][0]["event_id"]
    require([r for r in final["events"] if r["event_id"] == old_id] == before["events"], "Original event altered")
    require([r for r in final["outbox"] if r["event_id"] == old_id] == before["outbox"], "Original acknowledgement altered")
    require(all(r["emitted_at"] is not None for r in final["outbox"]), "Pending output remains")
    for state in (before, final):
        for row in state["events"]:
            packet = ww.History._checked(row)
            require(packet["origin"] == "LIVE_RPC" and packet["source"] == PROVIDER, "Stored packet origin")
    require(ww.History._checked(before["events"][0])["event"] == result["event"], "Reported event mismatch")
    config = json.loads(before["state"]["config"])
    require(config["address"] == selection["event"]["watched_address"], "Address selection mismatch")
    topic = "0x" + "0" * 24 + config["address"][2:]
    count = 0
    phase_queries = {}
    for directory in sorted(root.glob("*-rpc")):
        for i, path in enumerate(sorted(directory.glob("*.request.json")), 1):
            capture = read(path)
            require(capture["source_hostname"] == PROVIDER and capture["status"] == "RESPONSE_CAPTURED" and
                    capture["http_status"] == 200, "Unsuccessful or different-source RPC")
            request = capture["request"]
            require(request["id"] == i and request["method"] in ww.READ_METHODS, "RPC sequence/method")
            response_path = directory / capture["response_file"]
            require(sha(response_path) == capture["response_sha256"] and
                    response_path.stat().st_size == capture["response_bytes"], "RPC byte binding")
            response = read(response_path)
            require(response["jsonrpc"] == "2.0" and response["id"] == i and
                    "result" in response and "error" not in response, "RPC response envelope")
            if request["method"] == "eth_getLogs":
                phase_queries.setdefault(directory.name, []).append(request["params"][0])
            count += 1
    for phase, number in (("01-initial-scan-rpc", first), ("03-resumed-scan-rpc", target)):
        require(phase_queries[phase] == [{"address": ww.USDC, "fromBlock": hex(number), "toBlock": hex(number),
            "topics": topics} for topics in ([ww.TRANSFER, topic], [ww.TRANSFER, None, topic])], "Scan range/filter mismatch")
    commands = read(root / "commands.json")
    require(len(commands) == 7 and all(c["exit_code"] == 0 and c["fresh_process"] for c in commands), "CLI outcomes")
    resumed_command = next(c for c in commands if c["phase"] == "03-resumed-scan")
    require("--start-block" not in resumed_command["argv"], "Resume supplied start-block")
    resumed = records(root / "03-resumed-scan.stdout.jsonl")
    require(all(r.get("event_id") != old_id for r in resumed), "Prior notification repeated")
    require(resumed[-1] == result["resumed_scan"], "Resume summary mismatch")
    require(records(root / "05-restart-original-transaction.stdout.jsonl") == [result["transaction_replay"]] and
            result["transaction_replay"]["new_events"] == result["transaction_replay"]["console_notifications"] == 0,
            "Transaction replay counts")
    require(records(root / "04-history-after-resume.stdout.jsonl") ==
            records(root / "06-history-after-replay.stdout.jsonl"), "Live history changed after replay")
    require((root / "07-pending-notifications.stdout.jsonl").read_bytes() == b"", "Unexpected pending stdout")

    with tempfile.TemporaryDirectory(prefix="wallet-recent-offline-") as temporary:
        replay_db = Path(temporary) / "replay.sqlite3"
        replay_states = []
        for phase in LIVE_PHASES:
            child = subprocess.run([sys.executable, "-B", str(Path(__file__).resolve()), "--repo", str(repo),
                "--bundle", str(root), "--replay-phase", phase, "--replay-db", str(replay_db)],
                capture_output=True, text=True, timeout=30)
            require(child.returncode == 0, f"Offline replay failed: {phase}: {child.stderr}")
            replay_output = [json.loads(line) for line in child.stdout.splitlines() if line]
            require(normalized_output(replay_output) == normalized_output(records(root / (phase + ".stdout.jsonl"))),
                    "Offline CLI output differs beyond wall-clock-dependent packet digest")
            replay_states.append(snapshot(replay_db))
        require(normalized_state(replay_states[0], ww) == normalized_state(before, ww), "Initial replay state mismatch")
        require(normalized_state(replay_states[1], ww) == normalized_state(final, ww), "Resumed replay state mismatch")
        require(replay_states[1] == replay_states[2], "Offline transaction replay altered durable state")

    print(json.dumps({"status": "PASS", "source_head_sha": HEAD, "files_verified": len(expected),
        "rpc_responses_verified": count, "offline_cli_replays": len(LIVE_PHASES),
        "checkpoint_before": first, "checkpoint_after": target, "final_history_events": len(final["events"]),
        "replay_normalization": "ignore observed_at, created_at and emitted_at wall-clock values; retain acknowledgement state, packet contents, event projections, checkpoint and counts",
        "scope": "offline integrity and execution against captured RPC; no new live or independent network verification"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
