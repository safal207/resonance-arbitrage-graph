#!/usr/bin/env python3
"""Bounded public, read-only proof using PR #85's unmodified RPC/CLI code.

Capture wraps urllib response.read without changing requests or response bytes.
No private endpoint, credentials, fallback provider, signing or trading support.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

HEAD = "e2d644155b587da89b12116a9b94150c6e5d4837"
PROVIDER = "ethereum-rpc.publicnode.com"


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def install_capture(ww, directory):
    directory.mkdir(parents=True, exist_ok=False)
    original = ww.urlopen
    sequence = 0

    @contextmanager
    def captured(request, timeout):
        nonlocal sequence
        sequence += 1
        stem = f"{sequence:03d}"
        record = {"source_hostname": PROVIDER, "started_at": now(),
                  "request": json.loads(request.data), "status": "INCOMPLETE"}

        class Response:
            def __init__(self, response):
                self.response = response

            def read(self, size):
                raw = self.response.read(size)
                (directory / f"{stem}.response.json").write_bytes(raw)
                record.update(response_file=f"{stem}.response.json",
                              response_bytes=len(raw), response_sha256=hashlib.sha256(raw).hexdigest())
                return raw

        try:
            with original(request, timeout=timeout) as response:
                record["http_status"] = response.status
                yield Response(response)
            record["status"] = "RESPONSE_CAPTURED"
        except Exception as exc:
            record["status"] = "ERROR"
            record["error_type"] = type(exc).__name__
            raise
        finally:
            record["finished_at"] = now()
            save(directory / f"{stem}.request.json", record)

    ww.urlopen = captured


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--child", action="store_true")
    parser.add_argument("--phase")
    parser.add_argument("cli", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.out.resolve()
    sys.path.insert(0, str(repo / "src"))
    from resonance_arbitrage_graph import wallet_watch as ww
    from resonance_arbitrage_graph import wallet_watch_cli as cli

    if args.child:
        install_capture(ww, out / (args.phase + "-rpc"))
        cli_args = args.cli[1:] if args.cli[:1] == ["--"] else args.cli
        # Pin the one public endpoint, ignoring any operator environment override.
        if cli_args[0] in ("scan", "transaction"):
            cli_args += ["--rpc-url", ww.DEFAULT_RPC]
        return cli.main(cli_args)

    if out.exists() and any(out.iterdir()):
        raise RuntimeError("Use a new empty output directory; never overwrite an attempt")
    out.mkdir(parents=True, exist_ok=True)
    git = lambda *a: subprocess.check_output(["git", "-C", str(repo), *a], text=True).strip()
    if git("rev-parse", "HEAD") != HEAD or git("status", "--porcelain", "--untracked-files=no"):
        raise RuntimeError("Expected pristine pinned PR source")
    provenance = {"repository": "safal207/resonance-arbitrage-graph", "pr": 85,
                  "expected_head_sha": HEAD, "local_initial_head_sha": git("rev-parse", "HEAD"),
                  "started_at": now(), "python": sys.version, "source_hostname": PROVIDER,
                  "origin": "LIVE_RPC", "acquisition": "live read of an existing finalized transfer",
                  "capture": "urllib response.read wrapper; requests and response bytes unchanged",
                  "source_files": {}}
    for relative in ("src/resonance_arbitrage_graph/wallet_watch.py",
                     "src/resonance_arbitrage_graph/wallet_watch_cli.py"):
        provenance["source_files"][relative] = hashlib.sha256((repo / relative).read_bytes()).hexdigest()
    save(out / "provenance.json", provenance)
    trace = []
    result = {"status": "INCOMPLETE", "live_transfer_verified": False}

    def run(phase, cli_args):
        started = now()
        completed = subprocess.run([sys.executable, str(Path(__file__).resolve()),
                       "--repo", str(repo), "--out", str(out), "--child", "--phase", phase,
                       "--", *cli_args], capture_output=True, timeout=180)
        (out / f"{phase}.stdout.jsonl").write_bytes(completed.stdout)
        (out / f"{phase}.stderr.txt").write_bytes(completed.stderr)
        trace.append({"phase": phase, "argv": cli_args, "started_at": started,
                      "finished_at": now(), "exit_code": completed.returncode,
                      "fresh_process": True})
        save(out / "commands.json", trace)
        if completed.returncode:
            raise RuntimeError(f"{phase} failed; see retained stderr")
        return [json.loads(line) for line in completed.stdout.splitlines() if line]

    def check(value, message):
        if not value:
            raise RuntimeError(message)

    def checkpoint(db):
        with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as conn:
            row = conn.execute("SELECT cursor_number,cursor_hash FROM state WHERE id=1").fetchone()
            return list(row)

    try:
        install_capture(ww, out / "00-discovery-rpc")
        rpc = ww.Rpc(ww.DEFAULT_RPC)
        check(rpc.call("eth_chainId", []) == "0x1", "Wrong chain")
        finalized = rpc.call("eth_getBlockByNumber", ["finalized", False])
        block = ww.quantity(finalized["number"])
        logs = rpc.call("eth_getLogs", [{"address": ww.USDC, "fromBlock": hex(block),
                      "toBlock": hex(block), "topics": [ww.TRANSFER]}])
        check(isinstance(logs, list) and len(logs) <= 2000, "Unbounded/missing discovery result")
        events = [ww.decode_log(log) for log in logs]
        selected = None
        for event in sorted(events, key=lambda e: e["log_index"]):
            address = event["to_address"]
            count = sum(address in (e["from_address"], e["to_address"]) for e in events)
            if count == 1 and address != "0x" + "00" * 20 and int(event["amount_units"]) >= 1_000_000:
                selected = {**event, "watched_address": address}
                break
        check(selected is not None, "No qualifying single-transfer recipient in the one discovery block")
        save(out / "selection.json", {"selection_rule": "first log-index transfer >=1 USDC whose nonzero recipient occurs once in the provider-returned one-block USDC logs",
                                      "event": selected, "discovery_log_count": len(logs),
                                      "finalized_block": block, "selected_at": now(),
                                      "ownership_inferred": False})
        print(json.dumps({"phase": "selected", **selected}), flush=True)
        address, tx = selected["watched_address"], selected["tx_hash"]
        common = ["--address", address, "--min-usdc", "1"]
        txdb, scandb = out / "transaction.sqlite3", out / "scan.sqlite3"
        first = run("01-transaction", ["transaction", *common, "--tx", tx, "--db", str(txdb)])
        check(len(first) == 2 and first[-1]["new_events"] == 1 and first[-1]["console_notifications"] == 1,
              "Expected one event and notification on fresh transaction database")
        before = run("02-history", ["history", "--db", str(txdb)])
        check(len(before) == 1 and before[0]["origin"] == "LIVE_RPC" and before[0]["notification"] == "console_emitted", "Wrong live history")
        check(before[0]["event"]["tx_hash"] == tx and before[0]["event"]["log_index"] == selected["log_index"], "Selection mismatch")
        replay = run("03-transaction-restart", ["transaction", *common, "--tx", tx, "--db", str(txdb)])
        check(len(replay) == 1 and replay[0]["new_events"] == 0 and replay[0]["console_notifications"] == 0, "Transaction replay duplicated output")
        after = run("04-history-after-restart", ["history", "--db", str(txdb)])
        check(before == after, "Transaction history changed on restart")
        scan = run("05-one-block-scan", ["scan", *common, "--start-block", str(block), "--batch-size", "1", "--db", str(scandb)])
        check(len(scan) == 2 and scan[-1]["new_events"] == 1 and scan[-1]["console_notifications"] == 1, "Fresh scan did not emit one transfer")
        check(scan[-1]["from_block"] == block == scan[-1]["through_block"], "Scan escaped one block")
        scan_before = run("06-scan-history", ["history", "--db", str(scandb)])
        check(len(scan_before) == 1 and scan_before[0]["event"] == before[0]["event"], "Scan/transaction event mismatch")
        cursor_before = checkpoint(scandb)
        check(cursor_before == [block, selected["block_hash"]], "Wrong durable checkpoint")
        scan_replay = run("07-scan-db-restart-replay", ["transaction", *common, "--tx", tx, "--db", str(scandb)])
        check(len(scan_replay) == 1 and scan_replay[0]["new_events"] == 0 and scan_replay[0]["console_notifications"] == 0, "Scan database replay duplicated output")
        scan_after = run("08-scan-history-after-restart", ["history", "--db", str(scandb)])
        check(scan_before == scan_after and cursor_before == checkpoint(scandb), "Scan state changed on replay")
        drained = run("09-pending-notifications", ["notifications", "--db", str(scandb)])
        check(drained == [], "Unexpected pending output")
        result = {"status": "PASS", "live_transfer_verified": True, "event": before[0]["event"],
                  "scope": "one existing finalized transfer; one provider; two isolated fresh databases",
                  "fresh_transaction": first[-1], "transaction_restart": replay[-1],
                  "fresh_one_block_scan": scan[-1], "scan_db_restart_replay": scan_replay[-1],
                  "checkpoint_before_restart": cursor_before, "checkpoint_after_restart": checkpoint(scandb),
                  "offline_history_replay": "PASS", "pending_notifications_after_replay": 0,
                  "distinct_event_ids_across_paths": 1, "notifications_per_fresh_database": 1,
                  "notification_total_across_two_isolated_databases": 2,
                  "additional_notifications_on_same_database_replay": 0}
        print(json.dumps(result), flush=True)
    except Exception as exc:
        result.update(status="INCOMPLETE", error_type=type(exc).__name__, error=str(exc))
        print(json.dumps(result), flush=True)
    finally:
        provenance["finished_at"] = now()
        provenance["local_final_head_sha"] = git("rev-parse", "HEAD")
        provenance["local_tracked_dirty"] = bool(git("status", "--porcelain", "--untracked-files=no"))
        if provenance["local_final_head_sha"] != HEAD or provenance["local_tracked_dirty"]:
            result["status"] = "HOLD"
        save(out / "provenance.json", provenance)
        save(out / "result.json", result)
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    sys.exit(main())
